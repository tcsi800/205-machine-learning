import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd
import seaborn as sns

from collections import OrderedDict

sns.set()

uoa_colours = OrderedDict([
    ('Dark blue', '#00467F'),
    ('Light blue', '#009AC7'),
    ('Silver', '#8D9091')
    ])
uoa_faculty_colours = OrderedDict([
    ('Arts', '#A71930'),
    ('Business', '#7D0063'),
    ('Creative Arts and Industries', '#D2492A'),
    ('Education and Social Work', '#55A51C'),
    ('Engineering', '#4F2D7F'),
    ('Auckland Law School', '#005B82'),
    ('Medical and Health Sciences', '#00877C'),
    ('Science', '#0039A6')
])

def faculty_color_palette(faculty='Engineering'):
    faculties = list(uoa_faculty_colours.keys())
    assert faculty in faculties
    faculties.insert(0, faculties.pop(faculties.index(faculty)))
    colors = uoa_colours.copy()
    for faculty in faculties:
        colors[faculty] = uoa_faculty_colours[faculty]
    return sns.color_palette([color for name, color in colors.items()])

engineering_colors = faculty_color_palette()

sns.set_palette(engineering_colors)

def distribution(series, log_transformed=False,
                 swarmplot=False,
                 bins=None):
    '''
    Visualize distribution of pandas.Series as combination of histogram and boxplot

    The code has been adapted from ENGSCI762 Data Science module

    :param series: pandas.Series
    :return: fig
    '''
    # ENGSCI762 Data Science module
    # http://stackoverflow.com/questions/40070093/gridspec-on-seaborn-subplots
    gridkw = dict(height_ratios=[5, 1])
    fig, (ax1, ax2) = plt.subplots(2, 1, gridspec_kw=gridkw, sharex=True)
    if log_transformed:
        feature = pd.Series(np.log(series),
                           name = 'log({})'.format(series.name)
                           )
    else:
        feature = series
    sns.distplot(feature, ax=ax1, kde=False, bins=bins) #array, top subplot
    sns.boxplot(feature, ax=ax2, width=.4) #bottom subplot
    if swarmplot:
        sns.swarmplot(feature, ax=ax2,
                      size=2, color=".3", linewidth=0)

    ax1.set_xlabel('')
    ax1.text(1.05, 0.95,
             feature.describe().to_string(),
             transform=ax1.transAxes, fontsize=14,
             verticalalignment='top')
    #http://stackoverflow.com/questions/29813694/how-to-add-a-title-to-seaborn-facet-plot
    fig.subplots_adjust(top=0.9)
    fig.suptitle(feature.name, fontsize=16)
    return  fig, (ax1, ax2)


def distributions(series, species, log_transformed=False,
                 both_series=False, bins=None):
    '''
    Visualize distribution of pandas.Series as combination of histogram and boxplot

    The code has been adapted from ENGSCI762 Data Science module

    :param series: pandas.Series
    :return: fig
    '''
    # ENGSCI762 Data Science module
    # http://stackoverflow.com/questions/40070093/gridspec-on-seaborn-subplots
    gridkw = dict(height_ratios=[5, 1, 1])
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, gridspec_kw=gridkw, sharex=True)

    mask = np.asarray(species, 'bool')
    if log_transformed:
        feature = pd.Series(np.log(series),
                           name = 'log({})'.format(series.name)
                           )
    else:
        feature = series
    if not both_series:
        A = feature[~mask]
        B = feature[mask]
        Alabel = species.name
        Blabel = 'other'
    else:
        A = feature
        B = species
        Alabel = feature.name
        Blabel = species.name

    sns.distplot(A, ax=ax1,
                 kde=False,
                 label=Alabel,
                 color=engineering_colors[0],
                 bins=bins
                 ) #array, top subplot
    sns.distplot(B, ax=ax1,
                 kde=False,
                 label=Blabel,
                 color=engineering_colors[1],
                 bins=bins)  # array, top subplot
    ax1.legend()
    ax1.set_xlabel('')
    sns.boxplot(A, ax=ax2, width=.4)  # middle subplot
    ax2.set_xlabel('')

    current_palette = faculty_color_palette()
    sns.boxplot(B, ax=ax3, width=.4,
                color=current_palette[1],
                )  # bottom subplot
    return fig, (ax1, ax2, ax3)


def barplot(series):
    counts = series.value_counts()
    ax = counts.plot(kind='bar')
    plt.text(1.05, 0.95, str(counts),
             transform=ax.transAxes, fontsize=14,
             verticalalignment='top')

def savefig(filename, path='fig'):
    path_to_fig = os.path.join(path, filename)
    plt.savefig(path_to_fig, bbox_inches='tight')
    return path_to_fig

def saveorg(filename):
    output = "file:./{}".format(savefig(filename))
    return output