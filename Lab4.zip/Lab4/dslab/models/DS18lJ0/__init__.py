"""
DS18lJ0

These are some toy models for comparing machine learning models for the course.df dataset from the R package 's20x'.

"""

import pandas as pd

df = pd.read_csv('/Users/obi/04-Research/dsds/data/external/DS18lJ0__course_df.csv',
                 index_col=0)
X = df.drop('Exam', axis=1)
y = df['Exam']