"""
Most Data Science Models are always specific to a dataset.
Data set specific models are indicated by submodules, which are referencing the specific data set identifier starting
with DSyymdi

DS : Data Science
yy : last two digits of year
m  : letter [a-l] referencing the month
d  : letter [a-tA-K] referencing the day
i  : integer enumerating the experiment starting from 0
"""

__all__ = ['DS18lJ0']